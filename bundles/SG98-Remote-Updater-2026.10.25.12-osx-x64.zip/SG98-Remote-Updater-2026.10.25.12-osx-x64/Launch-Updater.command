#!/bin/sh
set -eu
cd -- "$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
if [ "$#" -eq 0 ]; then set -- --help; fi
exec "./SG98-Remote-Updater-2026.10.25.12" "$@"
